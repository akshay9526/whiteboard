import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:whiteboards_android/utils/AppConstants.dart';
import 'package:whiteboards_android/utils/Tools.dart';
import 'package:whiteboards_android/utils/utils.dart';

import 'draw/DrawAction.dart';
import 'draw/DrawingPainter.dart';
import 'draw/TextObject.dart';
import 'draw/TextPainterCanvas.dart';

class DrawingPad extends StatefulWidget {
  const DrawingPad({Key? key}) : super(key: key);

  @override
  State<DrawingPad> createState() => _DrawingPadState();
}

class _DrawingPadState extends State<DrawingPad> {
  final GlobalKey _globalKey = GlobalKey();
  final List<DrawAction> _actions = [];
  final List<DrawAction> _redoStack = [];

  Offset? _start;
  Offset? _end;
  Offset? _pointerPosition;
  bool _showPointer = false;

  // Current tool and drawing styles
  Tool _currentTool = Tool.pencil;
  Color _currentColor = Colors.black;
  double _strokeWidth = 2.0;
  int _polygonSides = 5;
  bool _isFilled = false;
  ui.Image? _backgroundImage;
  double _scale = 1.0;

  int? _selectedActionIndex;
  bool _isDragging = false;
  Offset _dragOffset = Offset.zero;

  DateTime now = DateTime.now();

  // Variables for the text tool
  String _currentText = '';
  TextStyle _currentTextStyle = TextStyle(fontSize: 20, color: Colors.black);
  final List<TextObject> textObjects = [];
  final TextEditingController textController = TextEditingController();
  final FocusNode textFocusNode = FocusNode();
  int? currentTextIndex;
  bool isTextFieldVisible = false;

  @override
  void initState() {
    super.initState();
    // Request storage permission when the widget is initialized
    _requestStoragePermission(context);
  }

  // Starts a new drawing action
  void _startDraw(Offset offset) {
    setState(() {
      _start = offset;
      _end = offset;
      // Add a new action for pencil or eraser tools
      if (_currentTool == Tool.pencil || _currentTool == Tool.eraser) {
        _actions.add(DrawAction(
          _currentTool,
          [_start!],
          _currentTool == Tool.eraser ? Colors.transparent : _currentColor,
          _strokeWidth,
          _polygonSides,
          _isFilled,
        ));
        _redoStack.clear(); // Clear redo stack on a new action
      }
    });
  }

  // Updates the current drawing action
  void _updateDraw(Offset offset) {
    setState(() {
      _end = offset;
      // Add points to the path for pencil or eraser
      if ((_currentTool == Tool.pencil || _currentTool == Tool.eraser) &&
          _actions.isNotEmpty) {
        _actions.last.pathPoints.add(offset);
      }
    });
  }

  // Ends the current drawing action
  void _endDraw() {
    // Add the completed action for shape tools
    if (_start != null &&
        _end != null &&
        _currentTool != Tool.pencil &&
        _currentTool != Tool.eraser) {
      _actions.add(DrawAction(
        _currentTool,
        [_start!, _end!],
        _currentColor,
        _strokeWidth,
        _currentTool == Tool.polygon ? _polygonSides : 0,
        _isFilled,
      ));
      _redoStack.clear(); // Clear redo stack on a new action
    }
    _start = null;
    _end = null;
    setState(() {});
  }

  // Selection and movement methods

  // Handles selection of a drawn object at the given position
  void _handleSelection(Offset position) {
    // Find the last action that contains this position
    for (int i = _actions.length - 1; i >= 0; i--) {
      if (_isPositionInAction(position, _actions[i])) {
        setState(() {
          _selectedActionIndex = i;
          _isDragging = true;
          _dragOffset = position;
        });
        return;
      }
    }
    // No action selected
    setState(() {
      _selectedActionIndex = null;
    });
  }

  // Moves the selected object based on the drag position
  void _moveSelectedObject(Offset position) {
    if (_selectedActionIndex != null && _isDragging) {
      final delta = position - _dragOffset;
      setState(() {
        // Move all points in the selected action by the delta
        for (int i = 0;
            i < _actions[_selectedActionIndex!].pathPoints.length;
            i++) {
          _actions[_selectedActionIndex!].pathPoints[i] += delta;
        }
        _dragOffset = position;
      });
    }
  }

  // Checks if a given position is within the bounds of a drawn action
  bool _isPositionInAction(Offset position, DrawAction action) {
    switch (action.tool) {
      case Tool.pencil:
      case Tool.eraser:
        // For freehand drawing, check if position is close to any line segment
        for (int i = 0; i < action.pathPoints.length - 1; i++) {
          if (_isPointNearLine(position, action.pathPoints[i],
              action.pathPoints[i + 1], action.strokeWidth)) {
            return true;
          }
        }
        return false;
      case Tool.line:
        return _isPointNearLine(position, action.pathPoints[0],
            action.pathPoints[1], action.strokeWidth);
      case Tool.rectangle:
        final rect =
            Rect.fromPoints(action.pathPoints[0], action.pathPoints[1]);
        return rect.contains(position) ||
            _isPointNearRectBorder(position, rect, action.strokeWidth);
      case Tool.circle:
        final center = (action.pathPoints[0] + action.pathPoints[1]) / 2;
        final radius =
            (action.pathPoints[0] - action.pathPoints[1]).distance / 2;
        final distance = (position - center).distance;
        return action.isFilled
            ? distance <= radius
            : (distance - radius).abs() <= action.strokeWidth / 2;
      case Tool.polygon:
        // Implement polygon hit testing
        return _isPointInPolygon(position, action);
      case Tool.text:
        // Implement text hit testing
        return _isPointInTextBounds(position, action);
      case Tool.select:
        return false; // Select tool itself is not selectable
    }
  }

  // Checks if a point is near a line segment
  bool _isPointNearLine(
      Offset point, Offset start, Offset end, double strokeWidth) {
    // Calculate the distance from point to line
    final dx = end.dx - start.dx;
    final dy = end.dy - start.dy;
    final length = sqrt(dx * dx + dy * dy);

    if (length < 0.0001) return (point - start).distance <= strokeWidth / 2;

    final t = ((point.dx - start.dx) * dx + (point.dy - start.dy) * dy) /
        (length * length);

    if (t < 0) return (point - start).distance <= strokeWidth / 2;
    if (t > 1) return (point - end).distance <= strokeWidth / 2;

    final projectionX = start.dx + t * dx;
    final projectionY = start.dy + t * dy;
    final distance = (point - Offset(projectionX, projectionY)).distance;

    return distance <= strokeWidth / 2;
  }

  // Checks if a point is near the border of a rectangle
  bool _isPointNearRectBorder(Offset point, Rect rect, double strokeWidth) {
    // Check if point is near any of the four edges of the rectangle
    final threshold = strokeWidth / 2;

    // Check left edge
    if (point.dx >= rect.left - threshold &&
        point.dx <= rect.left + threshold &&
        point.dy >= rect.top - threshold &&
        point.dy <= rect.bottom + threshold) {
      return true;
    }
    // Check right edge
    if (point.dx >= rect.right - threshold &&
        point.dx <= rect.right + threshold &&
        point.dy >= rect.top - threshold &&
        point.dy <= rect.bottom + threshold) {
      return true;
    }
    // Check top edge
    if (point.dy >= rect.top - threshold &&
        point.dy <= rect.top + threshold &&
        point.dx >= rect.left - threshold &&
        point.dx <= rect.right + threshold) {
      return true;
    }
    // Check bottom edge
    if (point.dy >= rect.bottom - threshold &&
        point.dy <= rect.bottom + threshold &&
        point.dx >= rect.left - threshold &&
        point.dx <= rect.right + threshold) {
      return true;
    }
    return false;
  }

  // Checks if a point is inside or near a polygon
  bool _isPointInPolygon(Offset point, DrawAction action) {
    // Implement polygon hit testing based on the polygon sides and points
    final sides = action.polygonSides;
    if (sides < 3) return false;
    final center = (action.pathPoints[0] + action.pathPoints[1]) / 2;
    final radius = (action.pathPoints[0] - action.pathPoints[1]).distance / 2;

    // For filled polygons (using ray casting algorithm)
    if (action.isFilled) {
      bool inside = false;
      List<Offset> vertices = [];
      for (int i = 0; i < sides; i++) {
        final angle = (2 * pi / sides) * i;
        final x = center.dx + radius * cos(angle);
        final y = center.dy + radius * sin(angle);
        vertices.add(Offset(x, y));
      }

      for (int i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
        if (((vertices[i].dy > point.dy) != (vertices[j].dy > point.dy)) &&
            (point.dx <
                (vertices[j].dx - vertices[i].dx) *
                        (point.dy - vertices[i].dy) /
                        (vertices[j].dy - vertices[i].dy) +
                    vertices[i].dx)) {
          inside = !inside;
        }
      }
      return inside;
    } else {
      // For outline polygons, check if near any edge
      for (int i = 0; i < sides; i++) {
        final angle1 = (2 * pi / sides) * i;
        final angle2 = (2 * pi / sides) * ((i + 1) % sides);
        final x1 = center.dx + radius * cos(angle1);
        final y1 = center.dy + radius * sin(angle1);
        final x2 = center.dx + radius * cos(angle2);
        final y2 = center.dy + radius * sin(angle2);
        if (_isPointNearLine(
            point, Offset(x1, y1), Offset(x2, y2), action.strokeWidth)) {
          return true;
        }
      }
      return false;
    }
  }

  // Checks if a point is within the approximate bounds of a text object
  bool _isPointInTextBounds(Offset point, DrawAction action) {
    if (action.pathPoints.isEmpty) return false;
    final start = action.pathPoints[0];
    // This is a rough estimate; for precise hit testing, you would need to calculate text size accurately
    final textLength = action.text.length;
    final textWidth = textLength * 10.0; // Rough estimate of text width
    final textHeight = 20.0; // Rough estimate of text height
    final rect =
        Rect.fromLTWH(start.dx, start.dy - textHeight, textWidth, textHeight);
    return rect.contains(point);
  }

  // Undoes the last drawing action
  void _undo() {
    if (_actions.isNotEmpty) {
      setState(() {
        _redoStack.add(_actions.removeLast());
      });
    }
  }

  // Redoes the last undone action
  void _redo() {
    if (_redoStack.isNotEmpty) {
      setState(() {
        _actions.add(_redoStack.removeLast());
      });
    }
  }

  // Clears all drawing actions and background image
  void _clear() {
    setState(() {
      _actions.clear();
      _redoStack.clear();
      _backgroundImage = null;
      textObjects.clear();
    });
  }

  // Sets the current drawing tool
  void _setTool(Tool tool) {
    setState(() {
      _currentTool = tool;
      // Hide text field if the tool is not text
      if (tool != Tool.text) {
        isTextFieldVisible = false;
      }
    });
  }

  // Sets the current drawing color
  void _setColor(Color color) {
    setState(() => _currentColor = color);
  }

  // Sets the current stroke width
  void _setStroke(double width) {
    setState(() => _strokeWidth = width);
  }

  // Exports the canvas as a PNG image
  Future<void> _exportCanvas() async {
    try {
      // Request storage permission
      bool hasPermission = await _requestStoragePermission(context);

      if (hasPermission) {
        final boundary = _globalKey.currentContext!.findRenderObject()
            as RenderRepaintBoundary;
        final image = await boundary.toImage(pixelRatio: 3.0);
        final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
        final pngBytes = byteData!.buffer.asUint8List();

        // Get the Downloads directory path
        final directory = await getExternalStorageDirectory();
        if (directory == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Could not access storage directory.')),
          );
          return;
        }

        final downloadsPath = '${directory.path}/Download';
        final downloadsDir = Directory(downloadsPath);

        // Create the Downloads directory if it doesn't exist
        if (!await downloadsDir.exists()) {
          await downloadsDir.create(recursive: true);
        }

        final fileName = "Whiteboard_" + Utils.generateFileName(now) + ".png";
        final file = File('$downloadsPath/$fileName');

        await file.writeAsBytes(pngBytes);

        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Exported to ${file.path}')));
      } else {
        // Inform the user if permission was not granted
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Please allow storage permission to export.')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error exporting image: $e')),
      );
    }
  }

  // Imports an image to be used as the background
  Future<void> _importImage() async {
    final picker = ImagePicker();
    final XFile? file = await picker.pickImage(source: ImageSource.gallery);
    if (file != null) {
      final data = await file.readAsBytes();
      final codec = await ui.instantiateImageCodec(data);
      final frame = await codec.getNextFrame();
      setState(() => _backgroundImage = frame.image);
    }
  }

  // Zooms in on the canvas
  void _zoomIn() {
    setState(() {
      _scale = min(_scale + 0.1, 3.0); // Limit max zoom-in to 3x
    });
  }

  // Zooms out on the canvas
  void _zoomOut() {
    setState(() {
      _scale = max(_scale - 0.1, 0.5); // Limit min zoom-out to 0.5x
    });
  }

  @override
  Widget build(BuildContext context) {
    // Set preferred orientation to landscape
    SystemChrome.setPreferredOrientations(
        [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(30.0),
        child: AppBar(
          title: Text(
            AppConstants.Whiteboard,
            style: TextStyle(fontSize: 18),
          ),
          backgroundColor: Colors.grey[200],
          leading: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset(
              'assets/icons/whiteboard.png', // Assuming you have this asset
            ),
          ),
        ),
      ),
      body: Row(
        children: [
          // Sidebar for tools and controls
          Container(
              width: 300,
              color: Colors.grey[100],
              child: SafeArea(child: _buildSidebar(context))),
          // Drawing area
          Expanded(
            child: GestureDetector(
              // Handle touch events for drawing and selection
              onPanStart: (details) {
                if (_currentTool == Tool.select) {
                  _handleSelection(details.localPosition);
                } else {
                  _startDraw(details.localPosition);
                }
              },
              onPanUpdate: (details) {
                if (_currentTool == Tool.select &&
                    _selectedActionIndex != null) {
                  _moveSelectedObject(details.localPosition);
                } else {
                  _updateDraw(details.localPosition);
                }
              },
              onPanEnd: (_) {
                if (_currentTool != Tool.select) {
                  _endDraw();
                } else {
                  _endDrag();
                }
              },
              // Stack to layer the drawing canvas and the text input field
              child: Stack(
                children: [
                  // RepaintBoundary for capturing the drawing as an image
                  RepaintBoundary(
                    key: _globalKey,
                    child: Stack(
                      children: [
                        // CustomPaint for drawing shapes and lines
                        CustomPaint(
                          size: Size.infinite,
                          painter: DrawingPainter(
                            _actions,
                            _backgroundImage,
                            _scale,
                            _currentTextStyle,
                          ),
                        ),
                        // CustomPaint for drawing text objects (rendered separately for better control)
                        CustomPaint(
                          size: Size.infinite,
                          painter: TextPainterCanvas(textObjects),
                        ),
                      ],
                    ),
                  ),
                  // GestureDetector to handle taps for placing text
                  Expanded(
                    child: GestureDetector(
                      onTapUp: (details) {
                        final position = details.localPosition;
                        bool tappedOnText = false;

                        // Check if a text object was tapped
                        for (int i = 0; i < textObjects.length; i++) {
                          final textObject = textObjects[i];
                          // Calculate text bounds (approximate)
                          final textSpan = TextSpan(
                            text: textObject.text,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 20,
                            ),
                          );
                          final textPainter = TextPainter(
                            text: textSpan,
                            textDirection: ui.TextDirection.ltr,
                          );
                          textPainter.layout();

                          final rect = Rect.fromLTWH(
                            textObject.x,
                            textObject.y,
                            textPainter.width,
                            textPainter.height,
                          );

                          if (rect.contains(position)) {
                            setState(() {
                              currentTextIndex = i;
                              textController.text = textObject.text;
                              textFocusNode.requestFocus();
                              isTextFieldVisible = true;
                            });
                            tappedOnText = true;
                            break;
                          }
                        }

                        // If not tapped on text and text tool is selected, add a new text object
                        if (!tappedOnText && _currentTool == Tool.text) {
                          setState(() {
                            textObjects.add(
                                TextObject(x: position.dx, y: position.dy));
                            currentTextIndex = textObjects.length - 1;
                            textController.clear();
                            textFocusNode.requestFocus();
                            isTextFieldVisible = true;
                          });
                        }
                      },
                      // CustomPaint for text drawing (again, for touch detection simplicity)
                      child: CustomPaint(
                        size: Size(double.infinity, double.infinity),
                        painter: TextPainterCanvas(textObjects),
                      ),
                    ),
                  ),
                  // Positioned text input field
                  if (isTextFieldVisible && currentTextIndex != null)
                    Positioned(
                      left: textObjects[currentTextIndex!].x,
                      top: textObjects[currentTextIndex!].y,
                      child: SizedBox(
                        width: 150, // Fixed width for the text field
                        height: 30, // Fixed height for the text field
                        child: TextField(
                          controller: textController,
                          focusNode: textFocusNode,
                          onChanged: (text) {
                            setState(() {
                              textObjects[currentTextIndex!].text = text;
                            });
                          },
                          onSubmitted: (_) {
                            setState(() {
                              isTextFieldVisible = false;
                            });
                          },
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            isDense: true,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Requests storage permission from the user
  Future<bool> _requestStoragePermission(BuildContext context) async {
    // Check the current status of storage permission
    var status = await Permission.storage.status;

    // If permission is already granted, return true
    if (status.isGranted) {
      print("Storage permission already granted."); // Added for debugging
      return true;
    }

    // If permission is denied, request it
    if (status.isDenied || status.isRestricted || status.isLimited) {
      print(
          "Storage permission status: $status. Requesting permission..."); // Added for debugging
      status = await Permission.storage.request();
      // Return true if the user granted the permission
      if (status.isGranted) {
        print(
            "Storage permission granted after request."); // Added for debugging
        return true;
      } else {
        print(
            "Storage permission denied after request."); // Added for debugging
        return false;
      }
    }

    // If permission is permanently denied, inform the user and ask them to go to settings
    if (status.isPermanentlyDenied) {
      print("Storage permission permanently denied."); // Added for debugging
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Storage permission permanently denied. Please enable it in settings.'),
        ),
      );
      // Open app settings for the user
      openAppSettings();
      return false; // Permission was not granted
    }

    // In any other case (e.g., unknown status), assume permission is not granted
    print(
        "Storage permission status unknown: $status. Assuming not granted."); // Added for debugging
    return false;
  }

  // Ends the drag operation for selection
  void _endDrag() {
    setState(() {
      _isDragging = false;
    });
  }

  @override
  void dispose() {
    textFocusNode.dispose(); // Dispose the focus node
    super.dispose();
  }

  // Builds the sidebar UI
  Widget _buildSidebar(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(10),
      children: [
        Text(AppConstants.SelectTool,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        const SizedBox(height: 0),
        // GridView for tool selection
        GridView.count(
          shrinkWrap: true,
          crossAxisCount: 4,
          mainAxisSpacing: 20,
          crossAxisSpacing: 0,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 1,
          children: Tool.values.map((tool) {
            final isSelected = _currentTool == tool;
            return GestureDetector(
              onTap: () {
                _setTool(tool);
                // Hide text field if the tool is not text
                if (tool != Tool.text) {
                  isTextFieldVisible = false;
                }
              },
              child: Card(
                color: isSelected ? Colors.blue.shade100 : Colors.white,
                elevation: isSelected ? 6 : 2,
                shape: RoundedRectangleBorder(
                  side: BorderSide(
                    color: isSelected ? Colors.blue : Colors.grey.shade300,
                    width: 2,
                  ),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(_getIconForTool(tool),
                        size: 18,
                        color: isSelected ? Colors.blue : Colors.black87),
                    const SizedBox(height: 8),
                    Text(tool.toString().split('.').last,
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: isSelected
                                ? FontWeight.bold
                                : FontWeight.normal)),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
        const Divider(),
        Text(AppConstants.PickColor,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        // Wrap for color selection
        Wrap(
          spacing: 10,
          children: Colors.primaries
              .map((color) => GestureDetector(
                    onTap: () => _setColor(color),
                    child: Container(
                      width: 25,
                      height: 25,
                      margin: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                        border: Border.all(
                          width: _currentColor == color ? 3 : 1,
                          color: Colors.grey[600]!,
                        ),
                      ),
                    ),
                  ))
              .toList(),
        ),
        const Divider(),
        Text(AppConstants.Stroke_Width,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        // Slider for stroke width
        Slider(
          activeColor: Colors.blueAccent,
          value: _strokeWidth,
          min: 1,
          max: 8,
          divisions: 7,
          label: _strokeWidth.toString(),
          onChanged: _setStroke,
        ),
        // Slider for polygon sides (only visible when polygon tool is selected)
        if (_currentTool == Tool.polygon) ...[
          const Divider(),
          Text(AppConstants.Polygon_Sides,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
          Slider(
            activeColor: Colors.blueAccent,
            min: 3,
            max: 10,
            divisions: 7,
            value: _polygonSides.toDouble(),
            label: _polygonSides.toString(),
            onChanged: (val) => setState(() => _polygonSides = val.toInt()),
          ),
        ],
        // No specific controls for text tool in sidebar (text input is on canvas)
        if (_currentTool == Tool.text) ...[],
        const Divider(),
        Text(AppConstants.Shape_Options,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        // Switch for filling shapes
        SwitchListTile(
          activeColor: Colors.blueAccent,
          title: Text(
            AppConstants.Fill_Shapes,
            style: TextStyle(fontWeight: FontWeight.normal, fontSize: 14),
          ),
          value: _isFilled,
          onChanged: (val) => setState(() => _isFilled = val),
        ),
        const Divider(),
        Text(AppConstants.Canvas_Controls,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        // List tiles for canvas controls
        ListTile(
            leading: const Icon(Icons.undo),
            title: Text(AppConstants.Undo,
                style: TextStyle(fontWeight: FontWeight.normal, fontSize: 14)),
            onTap: _undo),
        ListTile(
            leading: const Icon(Icons.redo),
            title: Text(AppConstants.Redo,
                style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12)),
            onTap: _redo),
        ListTile(
            leading: const Icon(Icons.clear_all),
            title: Text(AppConstants.Clear_All,
                style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12)),
            onTap: _clear),
        const Divider(),
        // List tiles for file operations
        ListTile(
            leading: const Icon(Icons.image),
            title: Text(AppConstants.Import_Image,
                style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12)),
            onTap: _importImage),
        ListTile(
          leading: const Icon(Icons.download),
          title: Text(AppConstants.Export_Image,
              style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12)),
          onTap: _exportCanvas,
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.upload_file),
          title: Text(AppConstants.Import_JSON,
              style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12)),
          onTap: _importJson,
        ),
        ListTile(
          leading: const Icon(Icons.download),
          title: Text(AppConstants.Export_JSON,
              style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12)),
          onTap: _exportJson,
        ),
        const Divider(),
        // List tiles for zoom controls
        Card(
          child: ListTile(
            leading: const Icon(Icons.zoom_in),
            title: Text(AppConstants.Zoom_In,
                style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12)),
            onTap: _zoomIn,
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.zoom_out),
            title: Text(AppConstants.Zoom_Out,
                style: TextStyle(fontWeight: FontWeight.normal, fontSize: 12)),
            onTap: _zoomOut,
          ),
        )
      ],
    );
  }

  // Gets the appropriate icon for a given tool
  IconData _getIconForTool(Tool tool) {
    switch (tool) {
      case Tool.pencil:
        return Icons.edit;
      case Tool.line:
        return Icons.linear_scale;
      case Tool.rectangle:
        return Icons.crop_square;
      case Tool.circle:
        return Icons.circle_outlined;
      case Tool.polygon:
        return Icons.change_history;
      case Tool.eraser:
        return Icons.cleaning_services;
      case Tool.text:
        return Icons.format_color_text_outlined;
      case Tool.select:
        return Icons.pan_tool;
    }
  }

  // Imports drawing data from a JSON file
  Future<void> _importJson() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['json'],
      );

      if (result != null && result.files.single.path != null) {
        File file = File(result.files.single.path!);
        String jsonString = await file.readAsString();
        _deserializeFromJson(jsonString);
      } else {
        // User canceled the picker
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error importing JSON: $e')),
      );
    }
  }

  // Serializes the drawing actions to a JSON string
  String _serializeToJson() {
    List<Map<String, dynamic>> jsonList = _actions.map((action) {
      return {
        'tool': action.tool.toString().split('.').last,
        'pathPoints': action.pathPoints
            .map((point) => {'dx': point.dx, 'dy': point.dy})
            .toList(),
        'color': action.color.value,
        'strokeWidth': action.strokeWidth,
        'polygonSides': action.polygonSides,
        'isFilled': action.isFilled,
        'text': action.text,
      };
    }).toList();
    return jsonEncode(jsonList);
  }

  // Deserializes drawing actions from a JSON string
  void _deserializeFromJson(String jsonString) {
    try {
      List<dynamic> jsonList = jsonDecode(jsonString);
      List<DrawAction> actions = jsonList.map((json) {
        return DrawAction(
          Tool.values.firstWhere(
              (tool) => tool.toString().split('.').last == json['tool']),
          (json['pathPoints'] as List)
              .map((point) => Offset(point['dx'], point['dy']))
              .toList(),
          Color(json['color']),
          json['strokeWidth'].toDouble(),
          json['polygonSides'] ?? 5,
          json['isFilled'] ?? false,
          json['text'] ?? '',
        );
      }).toList();

      setState(() {
        _actions.clear();
        _actions.addAll(actions);
        _selectedActionIndex = null; // Clear selection after import
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error parsing JSON: $e')),
      );
    }
  }

  // Exports the drawing data as a JSON file
  Future<void> _exportJson() async {
    try {
      // Request storage permission before attempting to export JSON
      bool hasPermission = await _requestStoragePermission(context);

      if (hasPermission) {
        final jsonString = _serializeToJson();

        // Get the Downloads directory path
        final directory = await getExternalStorageDirectory();
        if (directory == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content: Text('Could not access storage directory.')),
          );
          return;
        }

        final downloadsPath = '${directory.path}/Download';
        final downloadsDir = Directory(downloadsPath);

        // Create the Downloads directory if it doesn't exist
        if (!await downloadsDir.exists()) {
          await downloadsDir.create(recursive: true);
        }

        final fileName =
            'drawing_${"Whiteboard_" + Utils.generateFileName(DateTime.now())}.json';
        final file = File('$downloadsPath/$fileName');

        await file.writeAsString(jsonString);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('Exported to ${file.path}')));
      } else {
        // The _requestStoragePermission function already shows a SnackBar
        // for permanently denied. You can add a general message here if needed.
        // ScaffoldMessenger.of(context).showSnackBar(
        //   const SnackBar(content: Text('Storage permission required for export.')),
        // );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error exporting JSON: $e')),
      );
    }
  }
}
