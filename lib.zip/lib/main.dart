import 'package:flutter/material.dart';

import 'Draw.dart';

void main() => runApp(const DrawingPadApp());

class DrawingPadApp extends StatelessWidget {
  const DrawingPadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Whiteboard',
      home: DrawingPad(),
      debugShowCheckedModeBanner: false,
    );
  }
}
