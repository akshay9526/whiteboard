enum Tool { pencil, eraser, line, rectangle, circle, polygon, text, select }
