import 'package:intl/intl.dart';

class Utils {
  // Generates a unique file name based on the current date and time
  static String generateFileName(DateTime dateTime) {
    final DateFormat formatter = DateFormat('yyyyMMdd_HHmmss');
    return formatter.format(dateTime);
  }
}
